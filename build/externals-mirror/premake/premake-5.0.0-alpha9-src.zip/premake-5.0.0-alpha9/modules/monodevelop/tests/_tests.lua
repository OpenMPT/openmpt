require ("monodevelop")

return {
	"test_sln.lua",
	"test_project.lua",
	"test_config.lua",
}
