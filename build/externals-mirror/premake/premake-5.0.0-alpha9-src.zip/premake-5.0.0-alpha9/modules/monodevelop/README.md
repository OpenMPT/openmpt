Premake extension to support the [MonoDevelop](http://www.monodevelop.com)/[Xamarin Studio](http://xamarin.com/studio) IDE

### Features ###

* Support C/C++, C# and D (Mono-D) language projects

### Usage ###

Simply generate your project using the `monodevelop` action:
```bash
premake5 monodevelop
```
and open the generated project file in MonoDevelop/Xamarin Studio.
